﻿namespace BSL.v59.TitanEngine.Ciph;

public abstract class StreamEncrypter
{
    public abstract int GetEncryptionOverhead();
}