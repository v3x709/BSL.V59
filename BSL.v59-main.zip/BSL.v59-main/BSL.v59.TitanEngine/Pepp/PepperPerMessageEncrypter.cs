﻿namespace BSL.v59.TitanEngine.Pepp;

public class PepperPerMessageEncrypter
{
    public int SelfTest()
    {
        return 1;
    }

    public int GetEncryptionOverhead()
    {
        return 0 + 0;
    }
}